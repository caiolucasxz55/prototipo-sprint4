import type { MetroData } from "@/types/metro-type"

// This data is essential to the project and must remain unchanged
export const metroData: MetroData = {
  estacoes: [
    {
      id: "e1",
      nome: "Estação Central",
      linha: "Azul",
      conexoes: ["e2", "e5"],
    },
    {
      id: "e2",
      nome: "Estação Norte",
      linha: "Azul",
      conexoes: ["e1", "e3"],
    },
    {
      id: "e3",
      nome: "Estação Parque",
      linha: "Azul",
      conexoes: ["e2", "e4"],
    },
    {
      id: "e4",
      nome: "Estação Terminal",
      linha: "Azul",
      conexoes: ["e3"],
    },
    {
      id: "e5",
      nome: "Estação Mercado",
      linha: "Verde",
      conexoes: ["e1", "e6"],
    },
    {
      id: "e6",
      nome: "Estação Universidade",
      linha: "Verde",
      conexoes: ["e5", "e7"],
    },
    {
      id: "e7",
      nome: "Estação Shopping",
      linha: "Verde",
      conexoes: ["e6", "e8"],
    },
    {
      id: "e8",
      nome: "Estação Sul",
      linha: "Verde",
      conexoes: ["e7"],
    },
    {
      id: "e9",
      nome: "Estação Aeroporto",
      linha: "Vermelha",
      conexoes: ["e10"],
    },
    {
      id: "e10",
      nome: "Estação Centro",
      linha: "Vermelha",
      conexoes: ["e9", "e11", "e1"],
    },
    {
      id: "e11",
      nome: "Estação Industrial",
      linha: "Vermelha",
      conexoes: ["e10", "e12"],
    },
    {
      id: "e12",
      nome: "Estação Oeste",
      linha: "Vermelha",
      conexoes: ["e11"],
    },
  ],
  linhas: [
    {
      id: "l1",
      nome: "Azul",
      cor: "#0153a5",
      estacoes: ["e1", "e2", "e3", "e4"],
    },
    {
      id: "l2",
      nome: "Verde",
      cor: "#008061",
      estacoes: ["e5", "e6", "e7", "e8"],
    },
    {
      id: "l3",
      nome: "Vermelha",
      cor: "#ee1c25",
      estacoes: ["e9", "e10", "e11", "e12"],
    },
  ],
}
