export interface SavedRoute {
  id: string
  name: string
  stations: string[] // Array of station IDs
  createdAt: string
}
