import Link from "next/link"
import { Train } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 font-bold text-xl mb-4">
              <Train className="h-6 w-6 text-primary" />
              <span>Metrô SP</span>
            </div>
            <p className="text-sm text-muted-foreground">Sistema de planejamento de rotas para o Metrô de São Paulo.</p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/route-planner" className="text-sm text-muted-foreground hover:text-foreground">
                  Planejador de Rotas
                </Link>
              </li>
              <li>
                <Link href="/my-routes" className="text-sm text-muted-foreground hover:text-foreground">
                  Minhas Rotas
                </Link>
              </li>
              <li>
                <Link href="/estacao-map" className="text-sm text-muted-foreground hover:text-foreground">
                  Mapa de Estações
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Informações</h3>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground">
                Este é um projeto demonstrativo para planejamento de rotas do Metrô de São Paulo.
              </li>
              <li className="text-sm text-muted-foreground">
                Os dados utilizados são apenas para fins de demonstração.
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Metrô SP. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
